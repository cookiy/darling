//注册命名空间
baidu.editor.dom = baidu.editor.dom || {};